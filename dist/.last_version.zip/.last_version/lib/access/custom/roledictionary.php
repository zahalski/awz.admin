<?php
namespace Awz\Admin\Access\Custom;

use Awz\Admin\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}