<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_admin_before.php");
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Awz\Admin\Access\AccessController;
use Awz\Admin\Access\Custom\ActionDictionary;

global $APPLICATION;
$dirs = explode('/',dirname(__DIR__ . '../'));
$module_id = array_pop($dirs);
unset($dirs);
Loc::loadMessages(__FILE__);

if(!Loader::includeModule('awz.admin')) return;
if(!Loader::includeModule($module_id)) return;

if(!AccessController::can(0, ActionDictionary::ACTION_GENS_PAGE))
    $APPLICATION->AuthForm(Loc::getMessage("ACCESS_DENIED"));

/* "Awz\Admin\AdminPages\GensEdit" replace generator */
use Awz\Admin\AdminPages\GensEdit as PageItemEdit;

$APPLICATION->SetTitle(PageItemEdit::getTitle());
$arParams = PageItemEdit::getParams();

include($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/awz.admin/include/handler_el.php");
/* @var bool $customPrint */
if(!$customPrint) {
    $adminCustom = new PageItemEdit($arParams);
    $adminCustom->defaultInterface();
}