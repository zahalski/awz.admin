<?php
$MESS["GRID_COLUMNS_INCORRECT"] = "Некоректний параметр COLUMNS. Він повинен бути масивом колонок.";
$MESS["GRID_ID_INCORRECT"] = "Некоректний параметр GRID_ID. Він повинен бути не порожнім рядком, наприклад \"bitrix_example_grid\"";
$MESS["interface_grid_check"] = "Позначити для редагування";
$MESS["interface_grid_dblclick"] = "Подвійне натискання —";
$MESS["interface_grid_default_view"] = "<Подання за умовчанням>";
