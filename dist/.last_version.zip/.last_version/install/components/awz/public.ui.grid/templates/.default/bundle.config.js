module.exports = {
	input: './src/js/main.ui.grid.js',
	output: {
		js: './script.js',
		css: './style.css',
	},
	adjustConfigPhp: false,
};