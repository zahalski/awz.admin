<?
$arModuleVersion = array(
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2023-02-20 01:19:00"
);
?>