<?
$arModuleVersion = array(
    "VERSION" => "1.2.2",
    "VERSION_DATE" => "2024-12-08 11:27:00"
);
?>