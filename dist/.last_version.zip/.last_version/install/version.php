<?
$arModuleVersion = array(
    "VERSION" => "1.1.9",
    "VERSION_DATE" => "2024-10-03 13:46:00"
);
?>