<?
$arModuleVersion = array(
    "VERSION" => "1.1.14",
    "VERSION_DATE" => "2024-12-02 09:19:00"
);
?>