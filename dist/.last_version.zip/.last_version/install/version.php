<?
$arModuleVersion = array(
    "VERSION" => "1.2.3",
    "VERSION_DATE" => "2024-12-08 08:12:00"
);
?>