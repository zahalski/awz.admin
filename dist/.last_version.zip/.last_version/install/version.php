<?
$arModuleVersion = array(
    "VERSION" => "1.1.8",
    "VERSION_DATE" => "2024-04-18 20:27:00"
);
?>