<?
$arModuleVersion = array(
    "VERSION" => "1.1.11",
    "VERSION_DATE" => "2024-12-02 06:31:00"
);
?>