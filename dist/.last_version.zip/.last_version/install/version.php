<?
$arModuleVersion = array(
    "VERSION" => "1.1.10",
    "VERSION_DATE" => "2024-11-17 07:55:00"
);
?>