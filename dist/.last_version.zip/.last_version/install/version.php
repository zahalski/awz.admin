<?
$arModuleVersion = array(
    "VERSION" => "1.2.5",
    "VERSION_DATE" => "2024-12-29 21:44:00"
);
?>