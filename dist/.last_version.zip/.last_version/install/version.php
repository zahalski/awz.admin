<?
$arModuleVersion = array(
    "VERSION" => "1.1.13",
    "VERSION_DATE" => "2024-12-02 08:12:00"
);
?>