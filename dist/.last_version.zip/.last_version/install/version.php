<?
$arModuleVersion = array(
    "VERSION" => "1.1.7",
    "VERSION_DATE" => "2023-90-12 23:07:00"
);
?>