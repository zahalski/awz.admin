<?
$arModuleVersion = array(
	"VERSION" => "1.1.3",
	"VERSION_DATE" => "2023-07-19 14:40:00"
);
?>