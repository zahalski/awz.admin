<?
$arModuleVersion = array(
	"VERSION" => "1.1.6",
	"VERSION_DATE" => "2023-08-03 19:32:00"
);
?>