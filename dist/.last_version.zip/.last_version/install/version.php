<?
$arModuleVersion = array(
    "VERSION" => "1.1.16",
    "VERSION_DATE" => "2024-12-07 12:59:00"
);
?>