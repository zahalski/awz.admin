<?
$arModuleVersion = array(
	"VERSION" => "1.1.1",
	"VERSION_DATE" => "2023-07-18 18:07:00"
);
?>