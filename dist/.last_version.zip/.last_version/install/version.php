<?
$arModuleVersion = array(
	"VERSION" => "1.0.5",
	"VERSION_DATE" => "2023-03-24 01:11:00"
);
?>