<?
$arModuleVersion = array(
    "VERSION" => "1.1.17",
    "VERSION_DATE" => "2024-12-08 10:22:00"
);
?>