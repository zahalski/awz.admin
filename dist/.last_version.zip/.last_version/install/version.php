<?
$arModuleVersion = array(
    "VERSION" => "1.1.12",
    "VERSION_DATE" => "2024-12-02 08:00:00"
);
?>