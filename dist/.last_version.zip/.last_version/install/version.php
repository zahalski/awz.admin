<?
$arModuleVersion = array(
	"VERSION" => "1.1.2",
	"VERSION_DATE" => "2023-07-19 10:50:00"
);
?>