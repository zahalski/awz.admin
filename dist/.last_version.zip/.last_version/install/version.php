<?
$arModuleVersion = array(
    "VERSION" => "1.2.4",
    "VERSION_DATE" => "2024-12-08 16:34:00"
);
?>