drop table if exists b_awz_admin_goption;
drop table if exists b_awz_admin_gens;